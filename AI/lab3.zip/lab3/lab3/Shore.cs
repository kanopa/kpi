﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab3
{
    class Shore
    {
        public List<Person> Persons { set; get; } = new List<Person>();
    }
}
