﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab3
{
    class Person
    {
        public int Pair { set; get; }
        public string Type { set; get; }
    }
}
